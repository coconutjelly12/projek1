<div style="background-color: #1E90FF; height:60px;">
<footer class=" col-12 pt-3" style="margin-left:700px;">
<p>Created by <a class="text-dark" href="http://nurulfikri.ac.id">Pusinfo NF &copy;2017</a></p>
</footer>
</div>